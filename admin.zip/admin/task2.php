 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>First Name</th><th>Middle Name</th><th>Last Name</th><th>Email</th><th>Date of Birth</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "mydb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
//     {
//     $sql = "UPDATE admin_panel SET s_name='Khizar Ijaz' WHERE id=2";
// 
//     // Prepare statement
//     $stmt = $conn->prepare($sql);
// 
//     // execute the query
//     $stmt->execute();
// 
//     // echo a message to say the UPDATE succeeded
//     echo $stmt->rowCount() . " records UPDATED successfully";
//     }
     $e_id = $_POST["e_id"];
    $stmt = $conn->prepare("SELECT f_name, m_name, l_name,e_id,dob FROM s_personal WHERE e_id = '$e_id'");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";


?> 
