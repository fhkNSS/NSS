<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
	<title>FILE upload</title>
</head>
<body>
<form action="u_msheet.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file">
	<input type="text" name="s_email" placeholder="Email"  />
	<input type="submit" value="upload Marks Sheet">
</form>

<form action="u_bform.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file">
	<input type="text" name="s_email" placeholder="Email"  />
	<input type="submit" value="upload B Form">
</form>

<form action="u_sliability.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file">
	<input type="text" name="s_email" placeholder="Email"  />
	<input type="submit" value="upload Signed Liability">
</form>


</body>
</html>