<?php
if(isset($_FILES['file'])){
	$file = $_FILES['file'];
	
	//File properties
	$file_name = $file['name'];
	$file_tmp = $file['tmp_name'];
	$file_size = $file['size'];
	$file_error = $file['error'];

	//work out file extension
	$file_ext = explode('.', $file_name);
	$file_ext = strtolower(end($file_ext));

	$allowed	= array('txt', 'jpg','pdf');

	if (in_array($file_ext, $allowed)){
		if ($file_error === 0){
			$file_name_new = uniqid('',true). '.'.$file_ext;
			$file_destination = 'uploads/' . $file_name_new;
			sv_file_db($file_name_new);
			

			if(move_uploaded_file($file_tmp, $file_destination)) {
				echo $file_destination;
				
			}
		}
	}

	
}

function sv_file_db($file_name_new){
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$db="mydb";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn->set_charset("utf8");

 $s_email = $_POST["s_email"];

$stmt = $conn->prepare("UPDATE supplementary_documents SET l_form = '$file_name_new' WHERE s_email = '$s_email';");

$stmt->bind_param('s',$file_name_new);

$stmt->execute();

$sql="SELECT * FROM supplementary_documents WHERE l_form='$file_name_new'";
$result=$conn->query($sql);
if ($result->num_rows == 1) 
	header("Location: index.php");
}
