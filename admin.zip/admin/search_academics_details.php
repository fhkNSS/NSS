 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Student Email</th><th>Native Language</th><th>College Name</th><th>College Contact</th><th>O Levels/Fsc</th><th>O-level Type</th><th>O-level Major</th><th>A-level/matric Qualification</th><th>O-level Major</th><th>Matric/Equivalent Total Marks</th><th>Matric/Equivalent Obt Marks</th><th>A-Levels/Fsc/DAE Total Marks</th><th>A-levels/Fsc Obt Marks</th><th>Field Of interest</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "mydb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    //Updating Record of a student
    /*{
        $sql = "UPDATE admin_panel SET 
            s_name     = :s_name, 
            s_city     = :s_city,  
            s_email    = :s_email,  
            app_status = :app_status,
            fin_status = :fin_status,
            pay_status = :pay_status,
            s_class    = :s_class,
            s_interest = :s_interest,
            a_comm = :a_comm
            WHERE id = :id";
        $stmt = $conn->prepare($sql);                                  
        $stmt->bindParam(':s_name', $_POST['s_name'], PDO::PARAM_STR);       
        $stmt->bindParam(':s_city', $_POST['$s_city'], PDO::PARAM_STR);    
        $stmt->bindParam(':s_email', $_POST['s_email'], PDO::PARAM_STR);
        // use PARAM_STR although a number  
        $stmt->bindParam(':app_status', $_POST['app_status'], PDO::PARAM_STR); 
        $stmt->bindParam(':fin_status', $_POST['fin_status'], PDO::PARAM_STR);
        $stmt->bindParam(':pay_status', $_POST['pay_status'], PDO::PARAM_STR);
        $stmt->bindParam(':s_class', $_POST['s_class'], PDO::PARAM_STR);
        $stmt->bindParam(':s_interest', $_POST['s_interest'], PDO::PARAM_STR);
        $stmt->bindParam(':a_comm', $_POST['a_comm'], PDO::PARAM_STR);   
        $stmt->bindParam(':id', $_POST['id'], PDO::PARAM_INT);   
        $stmt->execute(); 
    }*/
  
    $s_email = $_POST["s_email"];
//     $sql="SELECT id, s_name, s_city, s_email, app_status, fin_status, pay_status, s_class, s_interest, a_comm FROM admin_panel WHERE s_email = $s_email"
    $stmt = $conn->prepare("SELECT id, s_email,n_lang,c_institution,i_contact, secondary,o_type,s_subjects,h_secondary,h_subjects,s_total,s_obtained,h_total,h_obtained,f_interest FROM s_academics WHERE s_email = '$s_email'");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

?> 

