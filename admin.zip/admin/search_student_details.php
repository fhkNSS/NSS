 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>First Name</th><th>Mid Name</th><th>Last Name</th><th>DOB</th><th>Gender</th><th>Nationality</th><th>Country</th><th>Id No.</th><th>Contact</th><th>Email</th><th>City</th><th>Province</th><th>Guardian Name</th><th>Guardian Contact</th><th>Secondary Contact</th><th>Financial Aid</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "mydb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    //Updating Record of a student
    /*{
        $sql = "UPDATE admin_panel SET 
            s_name     = :s_name, 
            s_city     = :s_city,  
            s_email    = :s_email,  
            app_status = :app_status,
            fin_status = :fin_status,
            pay_status = :pay_status,
            s_class    = :s_class,
            s_interest = :s_interest,
            a_comm = :a_comm
            WHERE id = :id";
        $stmt = $conn->prepare($sql);                                  
        $stmt->bindParam(':s_name', $_POST['s_name'], PDO::PARAM_STR);       
        $stmt->bindParam(':s_city', $_POST['$s_city'], PDO::PARAM_STR);    
        $stmt->bindParam(':s_email', $_POST['s_email'], PDO::PARAM_STR);
        // use PARAM_STR although a number  
        $stmt->bindParam(':app_status', $_POST['app_status'], PDO::PARAM_STR); 
        $stmt->bindParam(':fin_status', $_POST['fin_status'], PDO::PARAM_STR);
        $stmt->bindParam(':pay_status', $_POST['pay_status'], PDO::PARAM_STR);
        $stmt->bindParam(':s_class', $_POST['s_class'], PDO::PARAM_STR);
        $stmt->bindParam(':s_interest', $_POST['s_interest'], PDO::PARAM_STR);
        $stmt->bindParam(':a_comm', $_POST['a_comm'], PDO::PARAM_STR);   
        $stmt->bindParam(':id', $_POST['id'], PDO::PARAM_INT);   
        $stmt->execute(); 
    }*/
  
    $e_id = $_POST["e_id"];
//     $sql="SELECT id, s_name, s_city, s_email, app_status, fin_status, pay_status, s_class, s_interest, a_comm FROM admin_panel WHERE s_email = $s_email"
    $stmt = $conn->prepare("SELECT id, f_name,m_name,l_name, dob, gender,nationality,country,id_number,contact,e_id,city,province,g_name,g_contact,s_contact,f_aid FROM s_details WHERE e_id = '$e_id'");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

?> 

