 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Student Name</th><th>Student Email</th><th>Application Status</th><th>Fin Status</th><th>Payment Status</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "mydb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
   
  
    $e_id = $_POST["e_id"];
//     $sql="SELECT id, s_name, s_city, e_id, app_status, fin_status, pay_status, s_class, s_interest, a_comm FROM admin_panel WHERE e_id = $e_id"
    $stmt = $conn->prepare("SELECT s_name, e_id, app_status, fin_status,pay_status  FROM admin_panel WHERE e_id = '$e_id'");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

?> 

