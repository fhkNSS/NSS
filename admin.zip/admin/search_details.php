 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Email</th><th>Personal Statement</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "mydb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    
  
    $e_id = $_POST["e_id"];
    $stmt = $conn->prepare("SELECT id,e_id ,personal_statement FROM personal_statement WHERE e_id = '$e_id'");
    $stmt->execute();

    echo "Student Personal Statement<br>";
    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

echo "</table>";
echo "<br><br>";
?> 

 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Student Email</th><th>Native Language</th><th>College Name</th><th>College Contact</th><th>O Levels/Fsc</th><th>O-level Type</th><th>O-level Major</th><th>A-level/matric Qualification</th><th>A-level Major</th><th>Matric/Equivalent Total Marks</th><th>Matric/Equivalent Obt Marks</th><th>A-Levels/Fsc/DAE Total Marks</th><th>A-levels/Fsc Obt Marks</th><th>Field Of interest</th></tr>";



try {
    $stmt = $conn->prepare("SELECT id, e_id,n_lang,c_institution,i_contact, secondary,o_type,s_subjects,h_secondary,h_subjects,s_total,s_obtained,h_total,h_obtained,f_interest FROM s_academics WHERE e_id = '$e_id'");
    $stmt->execute();

    echo "Student Academic Details <br>";
    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
echo "</table>";
echo "<br><br>";
?> 



  <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>First Name</th><th>Mid Name</th><th>Last Name</th><th>DOB</th><th>Gender</th><th>Nationality</th><th>Country</th><th>Id No.</th><th>Contact</th><th>Email</th><th>City</th><th>Province</th><th>Guardian Name</th><th>Guardian Contact</th><th>Secondary Contact</th><th>Financial Aid</th></tr>";


try {
 
    $stmt = $conn->prepare("SELECT id, f_name,m_name,l_name, dob, gender,nationality,country,id_number,contact,e_id,city,province,g_name,g_contact,s_contact,f_aid FROM s_details WHERE e_id = '$e_id'");
    $stmt->execute();
    echo "Student Personal Details<br>";

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
echo "</table>";
echo "<br><br>"
?> 




 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Email</th><th>Marks Sheet</th><th>B Form</th><th>Signed Liability Form</th></tr>";


try {
    $stmt = $conn->prepare("SELECT e_id ,m_sheet, b_form,l_form FROM supplementary_documents WHERE e_id = '$e_id'");
    $stmt->execute();

    echo "Student Document Details";
    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

?> 



