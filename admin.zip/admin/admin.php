 <?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Student Name</th><th>Student Email</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "mydb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
//     {
//     $sql = "UPDATE admin_panel SET s_name='Khizar Ijaz' WHERE id=2";
// 
//     // Prepare statement
//     $stmt = $conn->prepare($sql);
// 
//     // execute the query
//     $stmt->execute();
// 
//     // echo a message to say the UPDATE succeeded
//     echo $stmt->rowCount() . " records UPDATED successfully";
//     }
    
    $stmt = $conn->prepare("SELECT id, s_name,e_id FROM admin_panel");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
    }
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

?> 
<html>
<form method="post" action="task1.php">
    	<input type="text" name="e_id" placeholder="Email"  />
        <button type="submit" class="btn btn-primary btn-block btn-large">Application Status</button>
        <!--<span> <?php echo $err ; ?> </span>-->
<!--         <br><a href="registers.html">Not a member yet? Sign up here!</a> -->
    </form>
    

<!--<form method="post" action="task2.php">
    	<input type="text" name="e_id" placeholder="Email"  />
        <button type="submit" class="btn btn-primary btn-block btn-large">SignUp Details</button>
        <!--<span> <?php echo $err ; ?> </span>-->
<!--         <br><a href="registers.html">Not a member yet? Sign up here!</a> -->
    </form>
    
    <form method="post" action="search_details.php">
    	<input type="text" name="e_id" placeholder="Email"  />
        <button type="submit" class="btn btn-primary btn-block btn-large">Details</button>
        <!--<span> <?php echo $err ; ?> </span>-->
<!--         <br><a href="registers.html">Not a member yet? Sign up here!</a> -->
    </form>

    <form method="post" action="search_academics_details.php">
    	<input type="text" name="e_id" placeholder="Email"  />
        <button type="submit" class="btn btn-primary btn-block btn-large">Student Academics Details</button>
        <!--<span> <?php echo $err ; ?> </span>-->
<!--         <br><a href="registers.html">Not a member yet? Sign up here!</a> -->
    </form>
    
     <form method="post" action="search_personal_details.php">
    	<input type="text" name="e_id" placeholder="Email"  />
        <button type="submit" class="btn btn-primary btn-block btn-large">Student Personal Statement</button>
        <!--<span> <?php echo $err ; ?> </span>-->
<!--         <br><a href="registers.html">Not a member yet? Sign up here!</a> -->
    </form>

     <form method="post" action="search_doc_details.php">
    	<input type="text" name="e_id" placeholder="Email"  />
        <button type="submit" class="btn btn-primary btn-block btn-large">Student Document Details</button>
        <!--<span> <?php echo $err ; ?> </span>-->
<!--         <br><a href="registers.html">Not a member yet? Sign up here!</a> -->
    </form>
    
    
</html>
