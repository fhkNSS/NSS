-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2017 at 02:30 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_panel`
--

CREATE TABLE `admin_panel` (
  `id` int(100) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `s_city` varchar(100) NOT NULL,
  `e_id` varchar(100) NOT NULL,
  `app_status` tinyint(1) NOT NULL,
  `fin_status` tinyint(1) NOT NULL,
  `pay_status` tinyint(1) NOT NULL,
  `s_class` varchar(100) NOT NULL,
  `s_interest` varchar(100) NOT NULL,
  `a_comm` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_panel`
--

INSERT INTO `admin_panel` (`id`, `s_name`, `s_city`, `e_id`, `app_status`, `fin_status`, `pay_status`, `s_class`, `s_interest`, `a_comm`) VALUES
(1, 'Huzaifa Mahmood Bajwa', 'Sargodha', 'itizhuzaifa@yahoo.com', 1, 0, 0, 'Fsc', 'poondi', 'So admirable interest'),
(2, 'Khizar Ijaz', 'Faisalabad', 'khizar@gmail.com', 0, 0, 0, '', '', ''),
(3, 'Mukarram Ishaq', '', 'muk@gmail.com', 0, 0, 0, 'SE-5A', 'Programming', 'none'),
(4, 'Obaid ur Rehman', 'Lhr', 'obaid@gmail.com', 0, 1, 1, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `personal_statement`
--

CREATE TABLE `personal_statement` (
  `id` int(10) NOT NULL,
  `personal_statement` varchar(1500) NOT NULL,
  `e_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personal_statement`
--

INSERT INTO `personal_statement` (`id`, `personal_statement`, `e_id`) VALUES
(1, 'Oo lalaoo lala', 'itizhuzaifa@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `supplementary_documents`
--

CREATE TABLE `supplementary_documents` (
  `id` int(10) NOT NULL,
  `m_sheet` varchar(100) NOT NULL,
  `b_form` varchar(100) NOT NULL,
  `l_form` varchar(100) NOT NULL,
  `e_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplementary_documents`
--

INSERT INTO `supplementary_documents` (`id`, `m_sheet`, `b_form`, `l_form`, `e_id`) VALUES
(3, '58fa094b928a76.89576226.pdf', '', '', 'itizhuzaifa@yahoo.com'),
(4, '', '', '58fa039c097e44.97190478.pdf', 'khizar@gmail.com'),
(5, '58fa0995687718.95992607.pdf', '58fa034af2ad61.86582979.pdf', '', 'khan@gmail.com'),
(6, '', '58fa09df2e4391.42659413.pdf', '58fa09f3af5ea9.37508247.pdf', 'mary@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `s_academics`
--

CREATE TABLE `s_academics` (
  `id` int(7) NOT NULL,
  `e_id` varchar(40) NOT NULL,
  `n_lang` varchar(40) NOT NULL,
  `c_institution` varchar(40) NOT NULL,
  `i_contact` varchar(40) NOT NULL,
  `secondary` varchar(40) NOT NULL,
  `o_type` varchar(40) NOT NULL,
  `s_subjects` varchar(40) NOT NULL,
  `h_secondary` varchar(40) NOT NULL,
  `h_subjects` varchar(40) NOT NULL,
  `s_total` double NOT NULL,
  `s_obtained` double NOT NULL,
  `h_total` double NOT NULL,
  `h_obtained` double NOT NULL,
  `f_interest` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s_academics`
--

INSERT INTO `s_academics` (`id`, `e_id`, `n_lang`, `c_institution`, `i_contact`, `secondary`, `o_type`, `s_subjects`, `h_secondary`, `h_subjects`, `s_total`, `s_obtained`, `h_total`, `h_obtained`, `f_interest`) VALUES
(1, 'itizhuzaifa@yahoo.com', 'urdu', 'Punjab College', '0323-7277982', 'O-levels', '2-years', 'Science', 'A levels', 'Science', 1100, 949, 1050, 967, 'Business'),
(2, 'mary@gmail.com', 'Urdu', 'Comsats', '0322-5012606', '', '', '', '', '', 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `s_details`
--

CREATE TABLE `s_details` (
  `id` int(100) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `m_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `country` varchar(100) NOT NULL,
  `id_number` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `e_id` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `g_name` varchar(100) NOT NULL,
  `g_contact` varchar(100) NOT NULL,
  `s_contact` varchar(100) NOT NULL,
  `f_aid` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s_details`
--

INSERT INTO `s_details` (`id`, `f_name`, `m_name`, `l_name`, `dob`, `gender`, `nationality`, `country`, `id_number`, `contact`, `e_id`, `city`, `province`, `g_name`, `g_contact`, `s_contact`, `f_aid`) VALUES
(1, 'Huzaifa', 'Mahmood', 'Bajwa', '21-1-2016', 'male', 'National', 'Pakistan', '12345', '12345', 'itizhuzaifa@yahoo.com', 'Isl', 'Fed', 'Arshad', '12345', '12345', 1),
(2, 'Maryam', 'Masood', 'Khan', '2016-1-01', 'female', 'National', 'Pakistan', '12345', '0323-7277982', 'mary@gmail.com', 'Isl', 'Federeal', 'Amjad Masood', '0321-5289862', '0323-7277980', 0);

-- --------------------------------------------------------

--
-- Table structure for table `s_personal`
--

CREATE TABLE `s_personal` (
  `id` int(7) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `m_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `dob` varchar(12) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `e_id` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `s_personal`
--

INSERT INTO `s_personal` (`id`, `f_name`, `m_name`, `l_name`, `dob`, `gender`, `e_id`, `password`) VALUES
(1, 'Huzaifa', 'Mahmood', 'Bajwa', '0000-00-00', 'male', 'itizhuzaifa@yahoo.com', '123'),
(2, 'Huzaifa', 'Mahmood', 'khan', '0000-00-00', 'male', 'itizhuzaifa@gmail.com', '789'),
(3, 'Khizar', 'Mahmood', 'Khan', '0000-00-00', 'male', 'itizhuzaifa@yahoo.com', '03237277982'),
(4, 'Raja ', 'Sajjad', 'Mahmood', '0000-00-00', 'male', 'raja@gmail.com', '123'),
(5, 'Maryam', 'Masood', 'Khan', '2016-01-01', 'female', 'mary@gmail.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_panel`
--
ALTER TABLE `admin_panel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_statement`
--
ALTER TABLE `personal_statement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplementary_documents`
--
ALTER TABLE `supplementary_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `s_academics`
--
ALTER TABLE `s_academics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `s_details`
--
ALTER TABLE `s_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `s_personal`
--
ALTER TABLE `s_personal`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_panel`
--
ALTER TABLE `admin_panel`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `personal_statement`
--
ALTER TABLE `personal_statement`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `supplementary_documents`
--
ALTER TABLE `supplementary_documents`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `s_academics`
--
ALTER TABLE `s_academics`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `s_details`
--
ALTER TABLE `s_details`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `s_personal`
--
ALTER TABLE `s_personal`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
