<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
	<title>FILE upload</title>
</head>
<body>
<form action="upload.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file">
	<input type="submit" value="upload">
</form>
</body>
</html>